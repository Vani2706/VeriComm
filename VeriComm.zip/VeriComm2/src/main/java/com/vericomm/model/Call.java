package com.vericomm.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import jakarta.persistence.*;

@Entity
public class Call {

	@Id
	private Integer callId;

	@Column(name = "call_duration")
	private Integer duration;

	@Column(name = "fromno")
	private String from;

	@Column(name = "tono")
	private String to;

	@ManyToOne
	@JoinColumn(name = "cid")
	private Customer customer;

	@ManyToOne
	@JoinColumn(name = "pid")
	private Plan plan;

	public Call() {
	}

	public Call(Integer callId, Integer duration, String from, String to, Customer customer, Plan plan) {
		super();
		this.callId = callId;
		this.duration = duration;
		this.from = from;
		this.to = to;
		this.customer = customer;
		this.plan = plan;
	}

	@Override
	public String toString() {
		return "Call [callId=" + callId + ", duration=" + duration + ", from=" + from + ", to=" + to + ", customer="
				+ customer + ", plan=" + plan + "]";
	}

	public Integer getCallId() {
		return callId;
	}

	public void setCallId(Integer callId) {
		this.callId = callId;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

}
