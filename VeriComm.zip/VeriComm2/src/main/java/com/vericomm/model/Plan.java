package com.vericomm.model;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Plan {
	@Id
	private Integer pid;
	private String pname;
	private Integer validity;
	private Integer duration_in_mins;
	private Float cost;

	public Plan() {
	}

	public Plan(Integer pid, String pname, Integer validity, Integer duration_in_mins, Float cost,
			List<Customer> customers) {
		this.pid = pid;
		this.pname = pname;
		this.validity = validity;
		this.duration_in_mins = duration_in_mins;
		this.cost = cost;

	}

	@Override
	public String toString() {
		return "Plan [pid=" + pid + ", pname=" + pname + ", validity=" + validity + ", duration_in_mins="
				+ duration_in_mins + ", cost=" + cost + "]";
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Integer getValidity() {
		return validity;
	}

	public void setValidity(Integer validity) {
		this.validity = validity;
	}

	public Integer getDurationInMins() {
		return duration_in_mins;
	}

	public void setDurationInMins(Integer duration_in_mins) {
		this.duration_in_mins = duration_in_mins;
	}

	public Float getCost() {
		return cost;
	}

	public void setCost(Float cost) {
		this.cost = cost;
	}

}
