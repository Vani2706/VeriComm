package com.vericomm.model;

import java.sql.Date;
import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Customer {
	@Id
	private Integer cid;
	private String cname;
	private String phn;
	private String email;
	private String location;
	private Date registerDate;

	@ManyToOne(optional = false)
	@JoinColumn(name = "pid")
	private Plan plan;

	public Customer() {
	}

	public Customer(Integer cid, String cname, String phn, String email, String location, Date registerDate, Plan plan,
			List<Call> calls) {
		this.cid = cid;
		this.cname = cname;
		this.phn = phn;
		this.email = email;
		this.location = location;
		this.registerDate = registerDate;
		this.plan = plan;
//        this.calls = calls;
	}

	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", cname=" + cname + ", phn=" + phn + ", email=" + email + ", location="
				+ location + ", registerDate=" + registerDate + ", plan=" + plan + /* ", calls=" + calls + */ "]";
	}

	// Getters and Setters...

	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getPhn() {
		return phn;
	}

	public void setPhn(String phn) {
		this.phn = phn;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

}
