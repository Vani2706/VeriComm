package com.vericomm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vericomm.dao.PlanDao;
import com.vericomm.exception.InvalidValidityException;
import com.vericomm.model.Plan;
@Service
public class PlanService {
	@Autowired
	PlanDao plandao;
	@SuppressWarnings("deprecation")
	public Plan getPlan(Integer pid) {
		Plan plan=plandao.findById(pid).get();		
		if (plan!=null)
			plandao.getById(pid);
		return plan;
	}

	public List<Plan> getPlans() {
		List<Plan> planList=plandao.findAll();
		return planList;
	}
	
	 public List<Plan> getPlanBelowThisCost(Float cost) {
	        return plandao.findPlanBelowThisCost(cost);

	}
	 public List<Plan> getPlansByCostRangeAndValidity(Float minCost, Float maxCost, Integer validity)  {
	        List<Plan> plan = plandao.findPlansByCostRangeAndValidity(minCost, maxCost, validity);
	        if(plan.isEmpty()) {
	        	throw new InvalidValidityException ("Oops ! The Inserted validity is not present . Just try either 30 or 60 . Thanks");
	        }
	        return plan;
	    }

	public List<Plan> getPlansByValidity(Integer validity) {
		List<Plan> plan = plandao.findPlansByValidity(validity);
		if(plan.isEmpty()) {
			throw new InvalidValidityException ("Oops ! The Inserted validity is not present . Just try either 30 or 60 . Thanks");
		}
		return plan;
	}



}




