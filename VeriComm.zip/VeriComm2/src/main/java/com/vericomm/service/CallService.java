package com.vericomm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vericomm.dao.CallDao;
import com.vericomm.dao.CustomerDao;
import com.vericomm.exception.CallNotFoundException;
import com.vericomm.model.Call;
import com.vericomm.model.Customer;
import com.vericomm.model.Plan;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CallService {

    @Autowired
    private CallDao callDao;
    
    @Autowired
    private CustomerDao customerDao;

    // Retrieve all call records
    public List<Call> getCallRecords() {
        return callDao.findAll();
    }

    // Retrieve calls by customer ID
    public List<Call> getCallsByCustomerId(Integer cid) {
        return callDao.findCallsByCustomerId(cid);
    }

   

   // Retrieve calls by customer ID and duration
    public List<Call> getCallsByCustomerIdAndDuration(Integer cid, Integer duration) {
        return callDao.findCallsByCustomerIdAndDurationGreaterThan(cid, duration);
    }

    // Retrieve total call duration by customer ID
    public Integer getTotalCallDurationByCustomerId(Integer cid) {
        return callDao.findTotalCallDurationByCustomerId(cid);
    }



    // Retrieve customers by plan ID
    public List<Customer> getCustomersByPlanId(Integer pid) {
        return callDao.findCustomersByPlanId(pid);
    }

    // Retrieve average call duration by plan ID
    public Double getAverageCallDurationByPlanId(Integer pid) {
        return callDao.findAverageCallDurationByPlanId(pid);
    }

	public String deleteCall(Integer callId) throws CallNotFoundException {
		Call call= callDao.findById(callId).orElse(null);
		String msg=null;
		if(call==null) {
			throw new CallNotFoundException("Call with ID "+callId+" not found.");
		}
		callDao.deleteById(callId);
	    msg= "Deleted Successfully...";
		

	return msg;
	}

	
	public String deleteByDuration(Integer callId) throws CallNotFoundException {
		Call call1=callDao.findById(callId).orElse(null);
		String msg=null;
		if(call1==null) {
			throw new CallNotFoundException("Call with ID "+callId+" not found.");
		}
			
		if(call1.getDuration()>1000) {
			 callDao.deleteById(callId);
			msg="Deleted Successfully..";
			}
		else
		 msg="Record cannot be deleted as the duration has not exceed 1000 minutes";
		
		return msg;
	}
		
		
			
	public Call updateCall(Integer callId,Integer duration) {
			Call call2=callDao.findById(callId).get();
			if(!call2.equals(null))
				call2.setDuration(duration);
			
			return callDao.findById(callId).get();
			
		}
		
	public String calculateRemainingORExceededDuration(Integer cid) {
		Optional<Customer> customer=customerDao.findById(cid);
		if(!customer.isPresent())
			throw new CallNotFoundException("Call with customer ID "+cid+" not found.");
		Customer customer1=customer.get();
		Plan plan=customer1.getPlan();
		Integer totalDuration=callDao.findTotalCallDurationByCustomerId(cid);
		Integer planDuration=plan.getDurationInMins();
		Float planCost=plan.getCost();
		if (totalDuration > planDuration) {
			Integer exceededDuration = totalDuration - planDuration;
			Float cost_per_min=planDuration/planCost;
			Float charges=exceededDuration*cost_per_min;
			return " Customer has exceeded the plan duration by " + exceededDuration + " minutes and your charges are "+charges;
		}
		else if(totalDuration == planDuration) {
			return " Customer has used the whole plan duration limit .";
		}
		else {
			Integer remainingDuration = planDuration - totalDuration;
			return " Customer has " + remainingDuration + " minutes remaining . .";
		}
	}

}
