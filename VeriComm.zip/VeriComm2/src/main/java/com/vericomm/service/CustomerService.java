package com.vericomm.service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vericomm.dao.CustomerDao;
import com.vericomm.exception.InvalidValidityException;
import com.vericomm.model.Customer;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class CustomerService {
	@Autowired
	CustomerDao customerDao;
	@SuppressWarnings("deprecation")
	public Customer getCustomers(Integer cid) {
		Customer customer=customerDao.findById(cid).get();		
		if (customer!=null)
			customerDao.getById(cid);
		return customer;
	}

	public List<Customer> getCustomers() {
		List<Customer> customerList=customerDao.findAll();
		return customerList;
	}
	
	public List<Customer> getCustomersRegisteredBetween(Date startDate, Date endDate) {
		 List<Customer> customer = customerDao.findByRegisterDateBetween(startDate, endDate);
		 if(customer.isEmpty()) {
			 throw new InvalidValidityException("Customer is not available between these given dates  . Thanks");
		 }
		 return customer;
	}
	
	public List<Customer> getCustomersByPlan(Integer pid){
		List<Customer> customer = customerDao.findCustomerByPlan(pid);
		if(customer.isEmpty()) {
        	throw new InvalidValidityException ("Customer is not available with given plan ID . Try Another one . Thanks");
        }
        return customer;
	}

}



