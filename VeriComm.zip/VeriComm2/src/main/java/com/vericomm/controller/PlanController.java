package com.vericomm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.vericomm.exception.InvalidValidityException;
import com.vericomm.model.Plan;
import com.vericomm.service.PlanService;

@RestController
public class PlanController {
	@Autowired
	PlanService planservice;

	@GetMapping("/plans")
	public List<Plan> getPlanDetails() {
		return planservice.getPlans();
	}

	@GetMapping("/plan/{pid}")
	public Plan getPlanDetails(@PathVariable("pid") Integer pid) {
		return planservice.getPlan(pid);
	}

	@GetMapping("/plan/{cost}/plans")
	public List<Plan> getPlanBelowThisCost(@PathVariable Float cost) {
		return planservice.getPlanBelowThisCost(cost);
	}

	@GetMapping("/cost/{minCost}/{maxCost}/validity/{validity}")
	public List<Plan> getPlansByCostRangeAndValidity(@PathVariable Float minCost, @PathVariable Float maxCost,
			@PathVariable Integer validity) {
		return planservice.getPlansByCostRangeAndValidity(minCost, maxCost, validity);
	}

	@GetMapping("/validity/{validity}")
	public List<Plan> getPlansByValidity(@PathVariable Integer validity) {
		return planservice.getPlansByValidity(validity);
	}

	@ExceptionHandler(InvalidValidityException.class)
	public ResponseEntity<String> handleInvalidValidityException(InvalidValidityException e) {
		return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
	}
}
