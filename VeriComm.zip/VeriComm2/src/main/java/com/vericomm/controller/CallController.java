package com.vericomm.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.vericomm.exception.CallNotFoundException;
import com.vericomm.model.Call;
import com.vericomm.model.Customer;
import com.vericomm.service.CallService;

@RestController
public class CallController {
	@Autowired
	CallService callService;

	@GetMapping("/calls")
	public List<Call> getCallDetails() {
		return callService.getCallRecords();
	}

	@GetMapping("/customer/{cid}/") // by giving the customer id you get all the call details the customer has.
	public List<Call> getCallsByCustomerId(@PathVariable Integer cid) {
		return callService.getCallsByCustomerId(cid);
	}

	@GetMapping("/customer/{cid}/total-duration")
	public Integer getTotalCallDurationByCustomerId(@PathVariable Integer cid) {
		return callService.getTotalCallDurationByCustomerId(cid);
	}

	@GetMapping("/plan/{pid}/customers")
	public List<Customer> getCustomersByPlanId(@PathVariable Integer pid) {
		return callService.getCustomersByPlanId(pid);
	}

	@GetMapping("/plan/{pid}/average-duration")
	public Double getAverageCallDurationByPlanId(@PathVariable Integer pid) {
		return callService.getAverageCallDurationByPlanId(pid);
	}

	@DeleteMapping("/calls/{callId}")
	public ResponseEntity<Object> deleteCallDetails(@PathVariable("callId") Integer callId)
			throws CallNotFoundException {
		try {

			String responseMessage = callService.deleteCall(callId);
			return new ResponseEntity<>(responseMessage, HttpStatus.OK);
		} catch (CallNotFoundException e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());

		}

	}

//delete call record if duration exceeded 1000 minutes        
	@DeleteMapping("/call/{callId}")
	public ResponseEntity<Object> deleteCallById(@PathVariable("callId") Integer callId) throws CallNotFoundException {
		try {

			String responseMessage = callService.deleteByDuration(callId);
			return new ResponseEntity<>(responseMessage, HttpStatus.OK);
		} catch (CallNotFoundException e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}

	}

	@PutMapping("/calls/{callId}/{duration}")
	public Call updateCallDetails(@PathVariable("callId") Integer callId, @PathVariable("duration") Integer duration) {
		return callService.updateCall(callId, duration);
	}

	@GetMapping("/calculateDuration/{cid}")
	public ResponseEntity<Object> calculateDuration(@PathVariable("cid") Integer cid) throws CallNotFoundException {
		try {
			String result = callService.calculateRemainingORExceededDuration(cid);
			return new ResponseEntity<>(result, HttpStatus.OK);
		} catch (CallNotFoundException e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}

	}

}
