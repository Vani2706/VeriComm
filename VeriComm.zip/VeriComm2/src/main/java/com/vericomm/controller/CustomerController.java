package com.vericomm.controller;

import java.sql.Date;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.vericomm.exception.InvalidValidityException;
import com.vericomm.model.Customer;
import com.vericomm.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	CustomerService customerService;

	@GetMapping("/customers")
	public List<Customer> getCustomerDetails() {
		return customerService.getCustomers();
	}

	@GetMapping("/customer/{cid}")
	public Customer getCustomerDetails(@PathVariable("cid") Integer cid) {
		return customerService.getCustomers(cid);
	}

	@GetMapping("/customers/{startDate}/{endDate}")
	public List<Customer> getCustomers(@PathVariable("startDate") Date startDate,
			@PathVariable("endDate") Date endDate) {
		return customerService.getCustomersRegisteredBetween(startDate, endDate);
	}

	// Retrieve customer and plan details from plan_id
	@GetMapping("/customers/{pid}")
	public List<Customer> getCustomersByPlan(@PathVariable Integer pid) {
		return customerService.getCustomersByPlan(pid);
	}

	@ExceptionHandler(InvalidValidityException.class)
	public ResponseEntity<String> handleInvalidValidityException(InvalidValidityException e) {
		return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
	}

}
