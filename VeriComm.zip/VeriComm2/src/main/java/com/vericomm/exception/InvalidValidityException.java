package com.vericomm.exception;

@SuppressWarnings("serial")
public class InvalidValidityException extends RuntimeException{
	public InvalidValidityException(String message) {
		super(message);
	}


}