package com.vericomm.exception;

@SuppressWarnings("serial")
public class CallNotFoundException extends RuntimeException {
	public CallNotFoundException(String message) {
		super(message);
	}

}
