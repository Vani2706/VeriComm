package com.vericomm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeriCommApplication {

	public static void main(String[] args) {
		SpringApplication.run(VeriCommApplication.class, args);
	}

}
