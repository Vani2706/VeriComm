package com.vericomm.dao;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.vericomm.model.Customer;

@Repository
public interface CustomerDao extends JpaRepository<Customer, Integer> {

	@Query("SELECT c FROM Customer c WHERE c.registerDate BETWEEN ?1 AND ?2")
	List<Customer> findByRegisterDateBetween(Date startDate, Date endDate);

	@Query("SELECT c FROM Customer c JOIN c.plan p WHERE p.pid = ?1")
	List<Customer> findCustomerByPlan(Integer pid);

	Optional<Customer> findByCid(Integer cid);

}
