package com.vericomm.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.vericomm.model.Call;
import com.vericomm.model.Customer;

@Repository
public interface CallDao extends JpaRepository<Call, Integer> {

	@Query("SELECT c FROM Call c WHERE c.customer.cid = ?1")
	List<Call> findCallsByCustomerId(Integer cid);

	@Query("SELECT c FROM Call c WHERE c.plan.pid = ?1")
	List<Call> findCallsByPlanId(Integer pid);

	@Query("SELECT c FROM Call c WHERE c.customer.cid = ?1 AND c.duration > ?2")
	List<Call> findCallsByCustomerIdAndDurationGreaterThan(Integer customerId, Integer duration);

	@Query("SELECT SUM(c.duration) FROM Call c WHERE c.customer.cid = ?1")
	Integer findTotalCallDurationByCustomerId(Integer cid);

	@Query("SELECT c FROM Call c WHERE c.customer.plan.pid = ?1")
	List<Call> findCallsByCustomerPlanId(Integer pid);

	@Query("SELECT DISTINCT c.customer FROM Call c WHERE c.plan.pid = ?1")
	List<Customer> findCustomersByPlanId(Integer pid);

	@Query("SELECT AVG(c.duration) FROM Call c WHERE c.plan.pid = ?1")
	Double findAverageCallDurationByPlanId(Integer pid);

}
