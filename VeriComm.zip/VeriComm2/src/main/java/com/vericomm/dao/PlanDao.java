package com.vericomm.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.vericomm.model.Plan;

@Repository
public interface PlanDao extends JpaRepository<Plan, Integer> {

	// JPQL query to find plans greater than given cost
	@Query("SELECT p FROM Plan p WHERE p.cost < ?1")
	List<Plan> findPlanBelowThisCost(Float cost);

	// Find plans by validity
	@Query("Select p from Plan p WHERE p.validity =?1")
	List<Plan> findPlansByValidity(Integer validity);

	// Custom JPQL query to find plans between cost range and validity
	@Query("SELECT p FROM Plan p WHERE p.cost BETWEEN ?1 AND ?2 AND p.validity = ?3")
	List<Plan> findPlansByCostRangeAndValidity(Float minCost, Float maxCost, Integer validity);

}
