package com.vericomm.VeriComm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeriCommApplicationTests {

	@Test
	void contextLoads() {
	}

}
